/*
 * Copyright (c) 2017 Payara Foundation and/or its affiliates. All rights reserved.
 *
 * The contents of this file are subject to the terms of either the GNU
 * General Public License Version 2 only ("GPL") or the Common Development
 * and Distribution License("CDDL") (collectively, the "License").  You
 * may not use this file except in compliance with the License.  You can
 * obtain a copy of the License at
 * https://github.com/payara/Payara/blob/master/LICENSE.txt
 * See the License for the specific
 * language governing permissions and limitations under the License.
 *
 * When distributing the software, include this License Header Notice in each
 * file and include the License file at glassfish/legal/LICENSE.txt.
 *
 * GPL Classpath Exception:
 * The Payara Foundation designates this particular file as subject to the "Classpath"
 * exception as provided by the Payara Foundation in the GPL Version 2 section of the License
 * file that accompanied this code.
 *
 * Modifications:
 * If applicable, add the following below the License Header, with the fields
 * enclosed by brackets [] replaced by your own identifying information:
 * "Portions Copyright [year] [name of copyright owner]"
 *
 * Contributor(s):
 * If you wish your version of this file to be governed by only the CDDL or
 * only the GPL Version 2, indicate your decision by adding "[Contributor]
 * elects to include this software in this distribution under the [CDDL or GPL
 * Version 2] license."  If you don't indicate a single choice of license, a
 * recipient has the option to distribute your version of this file under
 * either the CDDL, the GPL Version 2 or to extend the choice of license to
 * its licensees as provided above.  However, if you add GPL Version 2 code
 * and therefore, elected the GPL Version 2 license, then the option applies
 * only if the new code is made subject to such option by the copyright
 * holder.
 */
package de.ingoschindler.wild.security;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.authentication.mechanism.http.HttpAuthenticationMechanism;
import javax.security.enterprise.authentication.mechanism.http.HttpMessageContext;
import javax.security.enterprise.authentication.mechanism.http.RememberMe;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.IdentityStoreHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import io.jsonwebtoken.ExpiredJwtException;

@RememberMe(cookieMaxAgeSeconds = (24 * 60 * 60), isRememberMeExpression = "self.isRememberMe(httpMessageContext)")
@RequestScoped
public class JWTAuthenticationMechanism implements HttpAuthenticationMechanism {

	private static final Logger LOGGER = Logger.getLogger(JWTAuthenticationMechanism.class.getName());

	private static final String BEARER = "Bearer ";

	private static final String BASIC = "Basic ";

	private static final String AUTHORIZATION_HEADER = "Authorization";

	/**
	 * Access to the
	 * IdentityStore(AuthenticationIdentityStore,AuthorizationIdentityStore) is
	 * abstracted by the IdentityStoreHandler to allow for multiple identity stores
	 * to logically act as a single IdentityStore
	 */
	@Inject
	private IdentityStoreHandler identityStoreHandler;

	@Inject
	private TokenProvider tokenProvider;

	@Override
	public AuthenticationStatus validateRequest(HttpServletRequest request, HttpServletResponse response,
			HttpMessageContext context) {

		LOGGER.log(Level.INFO, "validateRequest: {0}", request.getRequestURI());
		// Get the (caller) name and password from the request
		// NOTE: This is for the smallest possible example only. In practice
		// putting the password in a request query parameter is highly insecure

		String name = null;
		String password = null;
		String authheader = extractAuthentication(context);
		if (authheader != null) {
			String[] auth = extractAuthentication(context).split(":");
			name = auth[0];
			password = auth[1];
		}

		String token = extractToken(context);

		if (name != null && password != null) {
			LOGGER.log(Level.INFO, "credentials : {0}, {1}", new String[] { name, password });
			// validation of the credential using the identity store
			CredentialValidationResult result = identityStoreHandler
					.validate(new UsernamePasswordCredential(name, password));
			if (result.getStatus() == CredentialValidationResult.Status.VALID) {
				// Communicate the details of the authenticated user to the container and return
				// SUCCESS.
				return createToken(result, context);
			}
			// if the authentication failed, we return the unauthorized status in the http
			// response
			return context.responseUnauthorized();
		} else if (token != null) {
			// validation of the jwt credential
			return validateToken(token, context);
		} else if (context.isProtected()) {
			// A protected resource is a resource for which a constraint has been defined.
			// if there are no credentials and the resource is protected, we response with
			// unauthorized status
			return context.responseUnauthorized();
		}
		// there are no credentials AND the resource is not protected,
		// SO Instructs the container to "do nothing"
		return context.doNothing();
	}

	/**
	 * To validate the JWT token e.g Signature check, JWT claims check(expiration)
	 * etc
	 *
	 * @param token   The JWT access tokens
	 * @param context
	 * @return the AuthenticationStatus to notify the container
	 */
	private AuthenticationStatus validateToken(String token, HttpMessageContext context) {
		try {
			if (tokenProvider.validateToken(token)) {
				JWTCredential credential = tokenProvider.getCredential(token);
				return context.notifyContainerAboutLogin(credential.getPrincipal(), credential.getAuthorities());
			}
			// if token invalid, response with unauthorized status
			return context.responseUnauthorized();
		} catch (ExpiredJwtException eje) {
			LOGGER.log(Level.INFO, "Security exception for user {0} - {1}",
					new String[] { eje.getClaims().getSubject(), eje.getMessage() });
			return context.responseUnauthorized();
		}
	}

	/**
	 * Create the JWT using CredentialValidationResult received from
	 * IdentityStoreHandler
	 *
	 * @param result  the result from validation of UsernamePasswordCredential
	 * @param context
	 * @return the AuthenticationStatus to notify the container
	 */
	private AuthenticationStatus createToken(CredentialValidationResult result, HttpMessageContext context) {
		if (!isRememberMe(context)) {
			String jwt = tokenProvider.createToken(result.getCallerPrincipal().getName(), result.getCallerGroups(),
					false);
			context.getResponse().setHeader(AUTHORIZATION_HEADER, BEARER + jwt);
		}
		return context.notifyContainerAboutLogin(result.getCallerPrincipal(), result.getCallerGroups());
	}

	/**
	 * To extract the JWT from Authorization HTTP header
	 *
	 * @param context
	 * @return The JWT access tokens
	 */
	private String extractToken(HttpMessageContext context) {
		String authorizationHeader = context.getRequest().getHeader(AUTHORIZATION_HEADER);

		if (authorizationHeader != null && authorizationHeader.startsWith(BEARER)) {
			String token = authorizationHeader.substring(BEARER.length(), authorizationHeader.length());
			return token;
		}
		return null;
	}

	private String extractAuthentication(HttpMessageContext context) {
		String authorizationHeader = context.getRequest().getHeader(AUTHORIZATION_HEADER);

		if (authorizationHeader != null && authorizationHeader.startsWith(BASIC)) {
			String token = authorizationHeader.substring(BASIC.length(), authorizationHeader.length());

			try {
				return new String(Base64.getDecoder().decode(token), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * this function invoked using RememberMe.isRememberMeExpression EL expression
	 *
	 * @param context
	 * @return The remember me flag
	 */
	public Boolean isRememberMe(HttpMessageContext context) {
		return Boolean.valueOf(context.getRequest().getParameter("rememberme"));
	}

}