package de.ingoschindler.wild.control;

public class PriceCalculator {

}
