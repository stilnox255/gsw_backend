package de.ingoschindler.wild.entity;

public class Ping {
	public String test = "test";
}